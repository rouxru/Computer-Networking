# Computer Nertworking - Coursework

Task 1: Code implementation
Task 2: Use of Wireshark for packets sniffing
Task3: Packet Tracer Testing
